---
name: test-importer-skill
description: A fixture skill used by SkillImporterTests
---

# Test Importer
Body.
