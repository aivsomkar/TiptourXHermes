# Loose notes, no SKILL.md — should be ignored entirely
